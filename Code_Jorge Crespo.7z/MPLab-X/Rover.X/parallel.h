void parallelInit(void);
void ReadParallel();


signed int  ReadParallelSpeedRight();
signed int ReadParallelSpeedLeft();
signed int ConvertParallelSpeed (char velocity);
unsigned int ReadMode();