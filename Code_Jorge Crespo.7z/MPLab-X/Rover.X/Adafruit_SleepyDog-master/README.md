# Adafruit SleepyDog Arduino Library

Arduino library to use the watchdog timer for system reset and low power sleep.

Currently supports the following hardware:
*   Arduino Uno or compatible (ATmega328P).
