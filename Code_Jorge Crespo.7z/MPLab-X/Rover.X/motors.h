/* 
 * File:   motors.h
 * Author: s00159395
 *
 * Created on 02 February 2016, 16:32
 */

void MotorInit();
void SetMotorLeft(signed int speed);
void SetMotorRight(signed int speed);
void Stop();
void WriteSpeedInLCD ();